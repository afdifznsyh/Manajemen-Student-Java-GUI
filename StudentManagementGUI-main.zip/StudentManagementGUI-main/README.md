# **Student Management App:**
![preview-image](./images/preview-1.png)
![preview-image](./images/preview-2.png)

## **Description:**
* CRUD App created in Java with a GUI made with JavaFX that allows the user to interact with a MySQL database to modify student records using JDBC
## **Features:**
* Allows users to create, read, update, and delete students from a database 
* GUI with a login and student database interface made with JavaFX
* Allows users to interact with a student database in MySQL with JDBC
## **Made using:**
* Java
* JavaFX
* JDBC
* MySQL
